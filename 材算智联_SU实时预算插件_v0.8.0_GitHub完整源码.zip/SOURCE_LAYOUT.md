# 源码结构

```text
src/
├─ su_material_budget.rb
└─ su_material_budget/
   ├─ main.rb
   ├─ dialog.html
   ├─ dialog_v07.html
   └─ materials.json
```

- `su_material_budget.rb`：SketchUp 扩展入口、版本信息与最低版本检查。
- `main.rb`：材质监听、实体遍历、面积与重叠计算、价格读取、AI候选、人工确认、预算汇总和导出。
- `dialog_v07.html`：v0.8.0 主界面及与 Ruby 回调的交互逻辑。
- `dialog.html`：兼容保留界面。
- `materials.json`：内置示例材料数据，不作为正式造价依据。

## 检查与重新打包

```powershell
node validate_v080.mjs
node validate_su2020_compat.mjs
python validate_v080_package.py
```

将 `src/su_material_budget.rb` 与 `src/su_material_budget/` 放在压缩包根目录，压缩为 ZIP 后把扩展名改为 `.rbz`。安装前应再次运行检查脚本，并在目标 SketchUp 版本中完成实机验证。
