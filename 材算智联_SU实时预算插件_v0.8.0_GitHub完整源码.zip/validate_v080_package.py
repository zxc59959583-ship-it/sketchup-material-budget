from pathlib import Path
from zipfile import ZipFile

package = Path("su_material_budget_v0.8.0_SU2020_compatible.rbz")
with ZipFile(package) as archive:
    loader = archive.read("su_material_budget.rb").decode("utf-8")
    main = archive.read("su_material_budget/main.rb").decode("utf-8")
    html = archive.read("su_material_budget/dialog_v07.html").decode("utf-8")
    print({
        "zip_ok": archive.testzip() is None,
        "entries": len(archive.namelist()),
        "version": "0.8.0" in loader and "v0.8.0" in html,
        "sketchup_2020_guard": "MINIMUM_SKETCHUP_VERSION = 20" in loader,
        "ruby_25_compatible": ".filter_map" not in main,
        "cef_64_compatible": "replaceAll(" not in html and "?." not in html,
        "deepseek": "https://api.deepseek.com/chat/completions" in main,
        "human_confirmation": "confirm_material_mapping" in main,
        "studio_dictionary": "studio_material_mappings" in main,
        "model_mapping_fallback": "MODEL_MAPPING_KEY" in main and "global_mappings.merge(parse_mapping_json(model_saved))" in main,
        "confirmation_updates_model": "model.set_attribute(DICT_NAME, MODEL_MAPPING_KEY" in main,
        "audit_ui": "mapping-history" in html,
        "progress_ui": "progress(data)" in html,
    })
